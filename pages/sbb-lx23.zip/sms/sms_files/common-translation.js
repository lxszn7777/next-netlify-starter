//this file should be maintained exactly the same for all patterns until a way of sharing a js lib is defined
function transl8(code) {
    var translationGroup = translation_data[code];
    if (translationGroup == null) {
        return code;
    }
    if (globalparameters.code === 'de') {
        return translationGroup["de"]
    } else if (globalparameters.code === 'fr') {
        return translationGroup["fr"]
    } else if (globalparameters.code === 'it') {
        return translationGroup["it"]
    } else {
        return translationGroup["en"]
    }
}


$(document).ready(function () {
    var domObjs = document.querySelectorAll("[data-transl8]");
    for (var i = 0; i < domObjs.length; i++) {
        domObjs[i].innerHTML = transl8(domObjs[i].getAttribute("data-transl8"));
    }
});

var translation_data = {
    "date.format": {
        "en": "mm/yy",
        "de": "tt/mm/jjjj",
        "fr": "jj/mm/aaaa",
        "it": "gg/mm/aaaa"
    }
}
