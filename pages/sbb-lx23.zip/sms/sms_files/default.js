$(document).ready(function () {

    $("#heaset-info")
        .mouseover(function () {
            $('div#help-line-number').fadeIn();
        })
        .mouseout(function () {
            $('div#help-line-number').hide();
        });

    //Disable link
    $('#heaset-info').click(function (e) {
        e.preventDefault();
    });
});


