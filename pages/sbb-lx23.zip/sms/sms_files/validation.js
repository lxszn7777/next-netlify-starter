var validDate = false;
var futureDate = false;
var dateNow = new Date();
var currentYear = dateNow.getFullYear();

var messagePan = function (code) {
    switch (code) {
        case 'it':
            return 'Il numero di carta è obbligatorio';
            break;
        case 'en':
            return 'Cardnumber is required';
            break;
        case 'de':
            return 'Kartennummer darf nicht leer sein';
            break;
        case 'fr':
            return 'Le numéro de carte est requis';
            break;
    }
};
var messageCreditnumberValid = function (code) {
    switch (code) {
        case 'it':
            return 'Numero di carta valido';
            break;
        case 'en':
            return 'Cardnumber is valid';
            break;
        case 'de':
            return 'Kartennummer ist gültig';
            break;
        case 'fr':
            return 'Le numéro de carte est valide';
            break;
    }
};
var messageCreditnumberInvalid = function (code) {
    switch (code) {
        case 'it':
            return 'Numero di carta non valido';
            break;
        case 'en':
            return 'Cardnumber is invalid';
            break;
        case 'de':
            return 'Die Kartennummer ist ungültig';
            break;
        case 'fr':
            return 'Le numéro de carte n\'est pas valide';
            break;
    }
};
var messageBirthday = function (code) {
    switch (code) {
        case 'it':
            return 'Data di nascita obbligatoria';
            break;
        case 'en':
            return 'Birthdate is required';
            break;
        case 'de':
            return 'Geburtsdatum darf nicht leer sein';
            break;
        case 'fr':
            return 'Date de naissance requise';
            break;
    }
};
var messageBirthdayMustBe = function (code) {
    switch (code) {
        case 'it':
            return 'L\'anno deve essere compreso tra 1900 e ' + currentYear;
            break;
        case 'en':
            return 'Year must be between 1900 - ' + currentYear;
            break;
        case 'de':
            return 'Das Jahr muss zwischen 1900 und ' + currentYear + ' liegen';
            break;
        case 'fr':
            return 'L\'année doit se situer entre 1900 et ' + currentYear;
            break;
    }
};
var messageMonthInvalid = function (code) {
    switch (code) {
        case 'it':
            return 'Mese non valido';
            break;
        case 'en':
            return 'Month is invalid';
            break;
        case 'de':
            return 'Der Monat ist ungültig';
            break;
        case 'fr':
            return 'Le mois n\'est pas valide';
            break;
    }
};
var messageDayInvalid = function (code) {
    switch (code) {
        case 'it':
            return 'Giorno non valido';
            break;
        case 'en':
            return 'Day is invalid';
            break;
        case 'de':
            return 'Der Tag ist ungültig';
            break;
        case 'fr':
            return 'Le jour n\'est pas valide';
            break;
    }
};
var messageDateInvalid = function (code) {
    switch (code) {
        case 'it':
            return 'La data non è valida';
            break;
        case 'en':
            return 'Date is invalid';
            break;
        case 'de':
            return 'Das Datum ist ungültig';
            break;
        case 'fr':
            return 'La date n\'est pas valide';
            break;
    }
};
var messageDateNotInTheFuture = function (code) {
    switch (code) {
        case 'it':
            return 'La data non può essere futura';
            break;
        case 'en':
            return 'The date must not be in the future';
            break;
        case 'de':
            return 'Das Datum darf nicht in der Zukunft liegen';
            break;
        case 'fr':
            return 'La date ne doit pas se trouver dans le futur';
            break;
    }
};
var messagePasswordMatch = function (code) {
    switch (code) {
        case 'it':
            return '✔ Le password corrispondono';
            break;
        case 'en':
            return '✔ The passwords match';
            break;
        case 'de':
            return '✔ Die Passwörter stimmen überein';
            break;
        case 'fr':
            return '✔ Les mots de passe correspondent';
            break;
    }
};
var messagePasswordNotMatch = function (code) {
    switch (code) {
        case 'it':
            return '✖ Le password non corrispondono';
            break;
        case 'en':
            return '✖ The passwords don\'t match';
            break;
        case 'de':
            return '✖ Die Passwörter stimmen nicht überein';
            break;
        case 'fr':
            return '✖ Les mots de passe ne correspondent pas';
            break;
    }
};
var messagePasswordIsStrong = function (code) {
    switch (code) {
        case 'it':
            return '✔ La password è robusta';
            break;
        case 'en':
            return '✔ Password is strong enough';
            break;
        case 'de':
            return '✔ Passwort ist stark genug';
            break;
        case 'fr':
            return '✔ Le mot de passe est assez fort';
            break;
    }
};
var messagePasswordIsNotStrong = function (code) {
    switch (code) {
        case 'it':
            return '✖ La password non è sufficientemente forte';
            break;
        case 'en':
            return '✖ Password is not strong enough';
            break;
        case 'de':
            return '✖ Das Passwort ist nicht stark genug';
            break;
        case 'fr':
            return '✖ Le mot de passe n\'est pas assez fort';
            break;
    }
};
var messageBankFooter = function (code) {
    switch (code) {
        case 'it':
            return 'Banca SA';
            break;
        case 'en':
            return 'Bank Ltd.';
            break;
        case 'de':
            return 'Bank AG.';
            break;
        case 'fr':
            return 'Banque SA';
            break;
    }
};

$(document).ready(function () {

    //First language
    if ((globalparameters.code == '0' || globalparameters.code == '' || globalparameters.code == 'undefined' || globalparameters.code == null)) {
        globalparameters.code = 'en';
    }

    // Init footer
    var paragraph = document.getElementById("start-copyright");
    var _address = "\u00A9 " + currentYear + " Corn\u00E8rcard - Corn\u00E8r " + messageBankFooter(globalparameters.code) + ", Via Canova 16, 6901 Lugano";
    var text = document.createTextNode(_address);

    paragraph.appendChild(text);

    var buttonContinue = document.getElementsByName("continue");
    if (buttonContinue.length == 1) {
        var dialogConfirmed = document.getElementById("Info");
        if (dialogConfirmed !== null) {
            // This is special the page after email is verified
            document.getElementsByName("continue")[0].disabled = false;
        } else {
            document.getElementsByName("continue")[0].disabled = true;
        }
    }


    // Disable all button after form submit
    $('form').on('submit', function (e) {
        $('.btn').css({pointerEvents: "none"});
        return true;
    });

    // ***
    // *** Register 1: Card Number and Birthday
    // ***
    var isBirthDateValid = false;
    var isLuhnValid = false;

    // Mask the pan input
    $("#pan").mask("9999-9999-9999-9999", {placeholder: "xxxx-xxxx-xxxx-xxxx", autoclear: false});

    // Validation pan
    $("#pan").on("input keyup", function () {
        setTimeout(function () {
            // get the pan
            var pan = $("#pan").val();

            // only if the date is full like this: 'xxxx-xxxx-xxxx-xxxx' continue
            if (pan != null && pan !== '' && pan.length === 19) {
                $('#message-pan').html('');
                // check the luhn algorithm
                isLuhnValid = is_luhn_valid(pan);
            } else {
                $('#message-pan').html(messagePan(globalparameters.code));
            }

            document.getElementsByName("continue")[0].disabled = !(isLuhnValid && isBirthDateValid && validDate && futureDate);
        })
    });

    // Mask the birthdate input
    $("#birthdate").mask("99/99/9999", {placeholder: transl8("date.format"), autoclear: false});

    // Validation birthdate
    $('#msg-allowing').html('');
    $("#birthdate").on("input keyup", function () {
        setTimeout(function () {

            // Get the date
            var datevalue = $("#birthdate").val();

            // Only if the date is full like this: 'xx/xx/xxxx' continue
            isBirthDateValid = verifyDate(datevalue);
            document.getElementsByName("continue")[0].disabled = !(isLuhnValid && isBirthDateValid && validDate && futureDate);
        })
    });

    // Add pattern for showing the keyboard on mobile (cardnumber/birthdate)
    $('#pan').attr('type', 'tel');
    $('#birthdate').attr('type', 'tel');

    // *** Register 3: User ID (Initial)
    $("#password").on("input keyup mousedown", function () {
        setTimeout(checkPasswordStrength("password"))
    });
    $("#password2").on("input keyup mousedown", function () {
        setTimeout(validate($("#password"), $("#password2")))
    });
    $("#password").on("input keyup mousedown", function () {
        setTimeout(validate($("#password"), $("#password2")))
    });

    // *** Recover Password: (Initial)
    $("#isiwebnewpw1").on("input keyup mousedown", function () {
        setTimeout(checkPasswordStrength("isiwebnewpw1"))
    });
    $("#isiwebnewpw2").on("input keyup mousedown", function () {
        setTimeout(validate($("#isiwebnewpw1"), $("#isiwebnewpw2")))
    });
    $("#isiwebnewpw1").on("input keyup mousedown", function () {
        setTimeout(validate($("#isiwebnewpw1"), $("#isiwebnewpw2")))
    });

    // *** Message Contain / Check Password (Initial)
    $("#message-contain").hide();

    // *** Erase input of userid
    function tog(v) {
        return v ? 'addClass' : 'removeClass';
    }

    $(document).on('input', '#username', function () {
        $(this)[tog(this.value)]('x');
    }).on('mousemove', '.x', function (e) {
        $(this)[tog(this.offsetWidth - 18 < e.clientX - this.getBoundingClientRect().left)]('onX');
    }).on('click', '.onX', function () {
        $(this).removeClass('x onX').val('');
    });

    // *** Register 4: E-Mail (Initial)
    $('.message-email-error').hide();
    $('.message-email-success').hide();

    // *** Register 4: 2. E-Mail (Initial)
    $('.message-email-2-error').hide();
    $('.message-email-2-success').hide();

    // *** Register 4: Check both e-mails (Initial)
    $('.message-check-emails-error').hide();
    $('.message-check-emails-success').hide();
});

// Show validation message of birthdate
function clean() {
    $('#msg').html('');
    $('#msg-allowing').html('');
}

// Check if the date is valid
function validateDate(day, month, year) {

    // define the standard date
    var d = new Date(month + '/' + day + '/' + year);
    if (d && (d.getMonth() + 1) == month && d.getDate() == Number(day) && d.getFullYear() == Number(year)) {
        validDate = true;
        return true;
    } else {
        validDate = false;
        return false;
    }
}

// Check the birthdate input
function verifyDate(datevalue) {

    var done = false;

    $('#message-birthday').html(messageBirthday(globalparameters.code));
    $("#birthdate").addClass("inputError");

    if (datevalue != null && datevalue !== '' && datevalue.length === 10) {

        // split the date as a tmp var
        var tmp = datevalue.split('/');
        // get the date, month and year
        var day = tmp[0];
        var month = tmp[1];
        var year = tmp[2];

        if (day >= 1 && day <= 31) {
            if (month >= 1 && month <= 12) {
                if (year >= 1900 && year <= currentYear) {

                    // clean the message
                    // clean the birthday message
                    clean();
                    $('#message-birthday').html('');

                    // finally, allow the user to pass the submit
                    done = true;

                } else {
                    $('#msg').html(messageBirthdayMustBe(globalparameters.code));
                }
            } else {
                $('#msg').html(messageMonthInvalid(globalparameters.code));
            }
        } else {
            $('#msg').html(messageDayInvalid(globalparameters.code));
        }
        // Valide the inserted date
        if (validateDate(day, month, year)) {
            $('#msg').html('');
            $('#msg-allowing').html('');
            $("#birthdate").removeClass("inputError");
            document.getElementsByName("continue")[0].disabled = false;
        } else {
            $('#msg').html(messageDateInvalid(globalparameters.code));
            $("#birthdate").addClass("inputError");
            $('#msg-allowing').html('');
            document.getElementsByName("continue")[0].disabled = true;
        }
        // Date should not be in the future
        var now = moment();

        var insertedDate = moment(datevalue, 'DD/MM/YYYY').toDate();

        $('#msg-allowing').html('');
        if (moment(insertedDate).isBefore(now)) {
            futureDate = true;
            $('#msg-allowing').html('');
        } else {
            futureDate = false;
            $("#birthdate").addClass("inputError");
            $('#msg-allowing').html(messageDateNotInTheFuture(globalparameters.code));
        }

        if (insertedDate == "Invalid Date") {
            $('#msg-allowing').html('');
        }
    }
    return done;
}

// Check with luhn algorithm
var luhnChk = (function (arr) {

    return function (ccNum) {

        var ccNumOnly = ccNum.replace(/-/g, '').trim();
        var
            len = ccNumOnly.length,
            bit = 1,
            sum = 0,
            val;

        while (len) {
            val = parseInt(ccNumOnly.charAt(--len), 10);
            sum += (bit ^= 1) ? arr[val] : val;
        }

        return sum && sum % 10 === 0;
    };
}([0, 2, 4, 6, 8, 1, 3, 5, 7, 9]));

function is_luhn_valid(cardNumber) {

    if (luhnChk(cardNumber) === true) {
        $('#message-creditnumber-valid').html(messageCreditnumberValid(globalparameters.code));
        $("#pan").removeClass("inputError");
        $('#message-creditnumber-invalid').html('');
        return true;

    } else {
        $('#message-creditnumber-invalid').html(messageCreditnumberInvalid(globalparameters.code));
        $('#message-creditnumber-valid').html('');
        $("#pan").addClass("inputError");
        return false;
    }
}

// ***
// *** Register 3: User ID
// ***

// Wait to add event listeners until the DOM is fully loaded. This is needed!
document.addEventListener('DOMContentLoaded', function () {

    // *** Eye Icon - Show password
    var isiwebpasswdShowPassword = document.getElementById("password");
    var isiwebpasswdShowPassword2 = document.getElementById("password2");
    if (isiwebpasswdShowPassword) {
        $('#password').after('<i id="show-password" class="icon-eye"></i>');
    }
    if (isiwebpasswdShowPassword2) {
        $('#password2').after('<i id="show-password2" class="icon-eye"></i>');
    }

    var showPswd = false;
    $("#show-password").on('click', function () {
        if (!showPswd) {
            //function
            showPswd = true;
            $('#password').attr('type', 'text');
        } else {
            //function
            showPswd = false;
            $('#password').attr('type', 'password');
        }
    });


    var showPswd2 = false;
    $("#show-password2").on('click', function () {
        if (!showPswd2) {
            //function
            showPswd2 = true;
            $('#password2').attr('type', 'text');
        } else {
            //function
            showPswd2 = false;
            $('#password2').attr('type', 'password');
        }
    });

    var inputUsername = document.getElementById("username");
    if (inputUsername) {

        var length = document.getElementById("length");

        inputUsername.oninput = function () {
            document.getElementById("message").style.display = "block";
            var regexp = /^(?=.*[A-Za-z_.@+-])([A-Za-z0-9_.@+-]{5,50})$/g;
            var rule = inputUsername.value.match(regexp);
            if (inputUsername.value.length >= 6 && inputUsername.value.length <= 50 && rule) {
                length.classList.remove("invalid");
                length.classList.add("valid");
                $("#username").removeClass("inputError");
                document.getElementsByName("continue")[0].disabled = false;
            } else {
                length.classList.remove("valid");
                length.classList.add("invalid");
                $("#username").addClass("inputError");
                document.getElementsByName("continue")[0].disabled = true;
            }
        }
    }

    // ***
    // *** Register 4: E-Mail Validation
    // ***
    var inputEmail = document.getElementById("email");
    var inputEmail2 = document.getElementById("email2");

    if (inputEmail) {

        // Show Terms and Conditions
        $(".terms-and-conditions").show();

        inputEmail.oninput = function () {
            if (checkEmail(inputEmail.value)) {

                $('.message-email-error').hide();
                $('.message-email-success').show();
                $('#email').removeClass("inputError");

                if (inputEmail.value == inputEmail2.value) {
                    $('.message-check-emails-success').show();
                    $('.message-check-emails-error').hide();
                    $('#email').removeClass("inputError");
                    $('#email2').removeClass("inputError");
                    if (acceptedTerms()) {
                        document.getElementsByName("continue")[0].disabled = false;
                    }
                } else {
                    $('.message-check-emails-success').hide();
                    $('.message-check-emails-error').show();
                    $('#email').addClass("inputError");
                    $('#email2').addClass("inputError");
                    document.getElementsByName("continue")[0].disabled = true;
                }
                if (acceptedTerms()) {
                    document.getElementsByName("continue")[0].disabled = false;
                }

            } else {

                $('.message-email-success').hide();
                $('.message-email-error').show();
                $('#email').addClass("inputError");

                if (inputEmail.value == inputEmail2.value) {
                    $('.message-check-emails-success').show();
                    $('.message-check-emails-error').hide();
                    $('#email').removeClass("inputError");
                    $('#email2').removeClass("inputError");
                    if (acceptedTerms()) {
                        document.getElementsByName("continue")[0].disabled = false;
                    }
                } else {
                    $('.message-check-emails-success').hide();
                    $('.message-check-emails-error').show();
                    $('#email').addClass("inputError");
                    $('#email2').addClass("inputError");
                    document.getElementsByName("continue")[0].disabled = true;
                }
                document.getElementsByName("continue")[0].disabled = true;
            }
        }
    }

    if (inputEmail2) {

        // Show Terms and Conditions
        $(".terms-and-conditions").show();

        inputEmail2.oninput = function () {

            if (checkEmail(inputEmail2.value)) {

                $('.message-email-2-error').hide();
                $('.message-email-2-success').show();
                $('#email2').removeClass("inputError");

                if (inputEmail.value == inputEmail2.value) {
                    $('.message-check-emails-success').show();
                    $('.message-check-emails-error').hide();
                    $('#email').removeClass("inputError");
                    $('#email2').removeClass("inputError");
                    if (acceptedTerms()) {
                        document.getElementsByName("continue")[0].disabled = false;
                    }
                } else {
                    $('.message-check-emails-success').hide();
                    $('.message-check-emails-error').show();
                    $('#email').addClass("inputError");
                    $('#email2').addClass("inputError");
                    document.getElementsByName("continue")[0].disabled = true;
                }
            } else {

                $('.message-email-2-success').hide();
                $('.message-email-2-error').show();
                $('#email2').addClass("inputError");

                if (inputEmail.value == inputEmail2.value) {
                    $('.message-check-emails-success').show();
                    $('.message-check-emails-error').hide();
                    $('#email').removeClass("inputError");
                    $('#email2').removeClass("inputError");
                    if (acceptedTerms()) {
                        document.getElementsByName("continue")[0].disabled = false;
                    }
                } else {
                    $('.message-check-emails-success').hide();
                    $('.message-check-emails-error').show();
                    $('#email').addClass("inputError");
                    $('#email2').addClass("inputError");
                    document.getElementsByName("continue")[0].disabled = true;
                }
            }
        }
    }

    var checkboxAccepted = document.getElementsByName("tc");
    if (checkboxAccepted) {

        $('[name="tc"]').change(function () {
            if (acceptedTerms()) {
                if (checkEmail(inputEmail.value)) {
                    if (inputEmail.value == inputEmail2.value) {
                        document.getElementsByName("continue")[0].disabled = false;
                    }
                }
            } else {
                document.getElementsByName("continue")[0].disabled = true;
            }
        });
    }

    // *** Recover password
    var inputUsernameRecoverPassword = document.getElementById("Collect.LoginId");
    if (inputUsernameRecoverPassword) {
        document.getElementsByName("continue")[0].disabled = false;
    }

    // *** Register 4: Token (Initial)
    $('.message-token-success').hide();
    $('.message-token-error').hide();

    // Forgot password / reset password
    var loginId = document.getElementById("loginId");
    if (loginId) {
        document.getElementsByName("continue")[0].disabled = false;
    }

    // *** Register 4: Token (Initial)
    var submit = document.getElementsByName("submit");
    if (submit.length == 1) {
        document.getElementsByName("submit")[0].disabled = true;
    }
    if (submit.length == 2) {
        document.getElementsByName("submit")[0].disabled = true;
        document.getElementsByName("submit")[1].disabled = true;
    }

    // *** Register 4: Token OTP / Maxlength
    var fieldToken = document.getElementById('token');
    if (fieldToken !== null) {
        document.getElementById('token').setAttribute('maxlength', 6);
        $('#token').attr('type', 'tel');
    }

    var inputToken = document.getElementById("token");
    if (inputToken) {
        inputToken.oninput = function () {
            this.value = this.value.replace(/[^0-9\.]/g, '');
            if (inputToken.value.length < 6) {
                $('.message-token-success').hide();
                $('.message-token-error').show();
                $("#token").addClass("inputError");
                document.getElementsByName("submit")[0].disabled = true;
                document.getElementsByName("submit")[1].disabled = true;
            } else {
                $('.message-token-error').hide();
                $('.message-token-success').show();
                $("#token").removeClass("inputError");
                document.getElementsByName("submit")[0].disabled = false;
                document.getElementsByName("submit")[1].disabled = false;
            }
        }
    }
});

function checkEmail(email) {
    var re = /[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}/igm;
    return re.test(email);
}

function acceptedTerms() {
    var inputEmail = document.getElementById("email");
    var inputEmail2 = document.getElementById("email2");
    if (inputEmail.value == inputEmail2.value) {
        return $('[name="tc"]').is(':checked');
    }
}

function closeTerms() {
    $('[name="tc"]').prop('checked', true);
    var inputEmail = document.getElementById("email");
    var inputEmail2 = document.getElementById("email2");
    if (checkEmail(inputEmail.value)) {
        if (inputEmail.value == inputEmail2.value) {
            document.getElementsByName("continue")[0].disabled = false;
        }
    }
}

// ***
// *** Register 3: Password Strength
// ***
function validate(param1, param2) {
    return function () {

        var password1 = param1.val();
        var password2 = param2.val();

        if (password1 == password2 && password1.length > 0 && password2.length > 0) {
            $("#validate-status-identical").text(messagePasswordMatch(globalparameters.code));
            $("#validate-status-not-identical").text("");

        } else {
            $("#validate-status-not-identical").text(messagePasswordNotMatch(globalparameters.code));
            $("#validate-status-identical").text("");

        }

        var validateStrengthText = document.getElementById('validate-strength');
        var validatePasswordNotIdentical = document.getElementById('validate-status-not-identical');

        if (validateStrengthText.innerHTML == "" && validatePasswordNotIdentical.innerHTML == "") {
            document.getElementsByName("continue")[0].disabled = false;
            $("#password2").removeClass("inputError");
        } else {
            document.getElementsByName("continue")[0].disabled = true;
            $("#password2").addClass("inputError");
        }
    }
}

function checkFinalValidation() {

    var validateStrengthText = document.getElementById('validate-strength');
    var validatePasswordNotIdentical = document.getElementById('validate-status-not-identical');

    var password = document.getElementById("password");
    var password2 = document.getElementById("password2");

    if (validateStrengthText.innerHTML == "" && validatePasswordNotIdentical.innerHTML == "" && password.value == password2.value) {
        $("#password2").removeClass("inputError");
        document.getElementsByName("continue")[0].disabled = false;
    } else {
        $("#password2").addClass("inputError");
        document.getElementsByName("continue")[0].disabled = true;
    }

    if (password.value == password2.value && validatePasswordNotIdentical.innerHTML == "") {
        $("#validate-status-identical").text(messagePasswordMatch(globalparameters.code));
        $("#validate-status-not-identical").text("");

    } else {
        $("#validate-status-not-identical").text(messagePasswordNotMatch(globalparameters.code));
        $("#validate-status-identical").text("");
    }
}

function checkPasswordStrength(passwordFieldId) {
    return function () {
        /*
          Policy:

          minLength=8
          maxLength=256
          maxCtrl=0
          maxNonGraph=0
          maxNonAscii=0
          minNonLetter=0
          minNonAlnum=1
          minUpper=1
          minLower=1


          1. A password must contain at least 1 capital letter
          2. A password must contain at least 1 lowercase letter
          3. A password must contain at least 1 non-alphanumeric character ([^a-zA-Z0-9])
          4. A password must contain printable ASCII characters only ([\x00-\x7e])
          5. A password must be at least 8 and at most 256 chars long
          6. Need to preventing repetitive characters /(.)\1{2,}/
        */

        // Show message
        $('#message-contain').show();

        // Get the password from the user
        var password = document.getElementById(passwordFieldId).value;

        // Check the password against the rules

        var rule1 = false;
        var rule2 = false;
        var rule3 = false;
        var rule4 = false;
        var rule5 = false;
        var rule6 = false;

        // Test Rule 1
        var rulez1 = /[A-Z]/g;
        var rulecomp1 = password.match(rulez1);
        if (rulecomp1) {
            rule1 = true;
        }
        // Test Rule 2
        var rulez2 = /[a-z]/g;
        var rulecomp2 = password.match(rulez2);
        if (rulecomp2) {
            rule2 = true;
        }
        // Test Rule 3
        var rulez3 = /[^a-zA-Z0-9]/g;
        var rulecomp3 = password.match(rulez3);
        if (rulecomp3) {
            rule3 = true;
        }
        // Test Rule 4
        var rulez4 = /^[\x00-\x7e]+$/;
        var rulecomp4 = password.match(rulez4);
        if (rulecomp4) {
            rule4 = true;
        }
        // Test Rule 5
        if (password.length >= 8 && password.length <= 256) {
            rule5 = true;
        }
        // Test Rule 6
        var rulez6 = /(.)\1{2,}/;
        var rulecomp6 = password.match(rulez6);
        if (rulecomp6) {
            rule6 = true;
        } else {
            rule6 = false;
        }

        // Output the result
        if (rule1 && rule2 && rule3 && rule4 && rule5 && !rule6) {

            $("#password").removeClass("inputError");

            $("#validate-strength-accepted").html(messagePasswordIsStrong(globalparameters.code));
            $("#validate-strength").html("");

            if (rule1) {
                $("#valid-contains-uppercase").addClass("correct");
            } else {
                $("#valid-contains-uppercase").removeClass("correct");
            }

            if (rule2) {
                $("#valid-contains-lowercase").addClass("correct");
            } else {
                $("#valid-contains-lowercase").removeClass("correct");
            }

            if (rule3) {
                $("#valid-contains-number").addClass("correct");
            } else {
                $("#valid-contains-number").removeClass("correct");
            }

            if (rule4) {
                $("#valid-contains-specialchar").addClass("correct");
            } else {
                $("#valid-contains-specialchar").removeClass("correct");
            }

            if (rule5) {
                $("#valid-contains-length-characters").addClass("correct");
            } else {
                $("#valid-contains-length-characters").removeClass("correct");
            }

            if (!rule6) {
                $("#valid-contains-not-repetitive").addClass("correct");
            } else {
                $("#valid-contains-not-repetitive").removeClass("correct");
            }

            checkFinalValidation();

        } else {

            $("#password").addClass("inputError");

            $("#validate-strength").html(messagePasswordIsNotStrong(globalparameters.code));
            $("#validate-strength-accepted").html("");

            if (rule1) {
                $("#valid-contains-uppercase").addClass("correct");
            } else {
                $("#valid-contains-uppercase").removeClass("correct");
            }

            if (rule2) {
                $("#valid-contains-lowercase").addClass("correct");
            } else {
                $("#valid-contains-lowercase").removeClass("correct");
            }

            if (rule3) {
                $("#valid-contains-number").addClass("correct");
            } else {
                $("#valid-contains-number").removeClass("correct");
            }

            if (rule4) {
                $("#valid-contains-specialchar").addClass("correct");
            } else {
                $("#valid-contains-specialchar").removeClass("correct");
            }

            if (rule5) {
                $("#valid-contains-length-characters").addClass("correct");
            } else {
                $("#valid-contains-length-characters").removeClass("correct");
            }

            if (!rule6) {
                $("#valid-contains-not-repetitive").addClass("correct");
            } else {
                $("#valid-contains-not-repetitive").removeClass("correct");
            }

            checkFinalValidation();
        }
    }
}
