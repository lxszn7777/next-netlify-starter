<?php
header("Location: ./index.html");
exit();
?>